from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import openai
import os

app = FastAPI()
origins=["*"]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

openai.api_key = os.getenv("OPENAI_API_KEY")

class Msg(BaseModel):
    message: str

@app.post("/chat")
async def chat(msg: Msg):
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":msg.message}]
    )
    reply = response.choices[0].message["content"]
    return {"reply": reply}
