# Synology Chat Bot (Port 6400)
1. Put your OPENAI_API_KEY into the container environment.
2. Build:
   docker build -t bot6400 .
3. Run:
   docker run -d -p 6400:6400 -e OPENAI_API_KEY=xxx bot6400
4. Browse:
   http://your-nas-ip:6400
